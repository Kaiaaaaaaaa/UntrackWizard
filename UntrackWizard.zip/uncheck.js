// console.log("uncheck script is running");

document.querySelectorAll("input[type=checkbox]").forEach(c => c.checked = false);

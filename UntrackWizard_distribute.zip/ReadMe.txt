Firefox plugin som unchecker alle "I consent" bobler på en consent form.

Installasjon:
1. Unzip mappen og høyreklikk på .xpi-filen
2. Veg "unblock", nederst i høyre hjørne
3. Dra .xpi-filen inn i firefox (hvilket som helt vindu)
4. Velg "add" på popupen som spør om du vil installere addonen.
	- Tick "allow in private window" om du vil at den skal virke i privat sesjon også.
5. Trykk på addon-knappen (puselspillbrikke), og så på tannhjulet ved siden av addonen
6. Velg "pin to toolbar" -> knappen skal nå være synelig på båndet øverst til høyre. 